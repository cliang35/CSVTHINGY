﻿Public Class Form1

    Sub Read_File()
        Dim FILE1 As Short
        Dim FILE2 As Short
        Dim FILE3 As Short
        Dim SCRATCH As String
        Dim DATAFILE As String
        Dim FILENO As Short

        DATAFILE = "C:\cfiles\los alamos\GasConsumption_Engineering_DSegura.csv"

        'OPEN FILE
        FILENO = FreeFile()
        FileOpen(FILENO, DATAFILE, OpenMode.Input)

        'OUTPUT
        FILE1 = FreeFile()
        FileOpen(FILE1, DATAFILE & "_1", OpenMode.Output)
        FILE2 = FreeFile()
        FileOpen(FILE2, DATAFILE & "_2", OpenMode.Output)
        FILE3 = FreeFile()
        FileOpen(FILE3, DATAFILE & "_3", OpenMode.Output)

        SCRATCH = LineInput(FILENO)

        Do While Not EOF(FILENO)
            SCRATCH = LineInput(FILENO)
            Print(FILE1, SCRATCH & Chr(13) & Chr(10))

            SCRATCH = LineInput(FILENO)
            Print(FILE2, SCRATCH & Chr(13) & Chr(10))

            SCRATCH = LineInput(FILENO)
            Print(FILE3, SCRATCH & Chr(13) & Chr(10))

        Loop

        'CLOSE FILE
        FileClose(FILENO, FILE1, FILE2, FILE3)


    End Sub

    Private Sub Send_Click(sender As Object, e As System.EventArgs) Handles Send.Click
        Call Read_File()
        MsgBox("Complete")
    End Sub
End Class
